package Pkg1;

public class Test {
	public void show() {
		System.out.println("This is show method 1");
	}
	
	//2nd test eke paremeters thiyanava...
	//method overloading karanna puluvan 1 class ekaka vitharai.
	public void show(int num) {
		System.out.println("This is from show method 2");
	}

}
