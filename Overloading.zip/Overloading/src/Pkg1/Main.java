package Pkg1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t1 = new Test();
		
		t1.show();
		t1.show(0);
	}

}
